<?php
__( 'WP-Parsidate', 'wp-parsidate' );
__( 'Persian package for WordPress, Adds full RTL and Shamsi (Jalali) support for: posts, comments, pages, archives, search, categories, permalinks and all admin sections and TinyMce editor, lists, quick editor. This package has Jalali archive widget.', 'wp-parsidate' );
__( 'WP-Parsi Team', 'wpo' );